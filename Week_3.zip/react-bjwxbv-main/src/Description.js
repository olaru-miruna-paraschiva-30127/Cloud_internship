import React from "react";

export default function Description() {
  return (
    <div>
      <textarea style={{backgroundColor:'rgb(230,231,243)', border:'1px solid rgb(190,190,190)',
   borderRadius:'8px',width:'100%',height:'150px'}} placeholder="Description"/>
    </div>
  );
}
